#include <stdio.h>

void baz()
{
	printf("This is baz() source file baz.c\n");
}