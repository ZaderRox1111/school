#include <stdio.h>

int bar()
{
	printf("This is bar() source file bar.c\n");
	return 5;
}